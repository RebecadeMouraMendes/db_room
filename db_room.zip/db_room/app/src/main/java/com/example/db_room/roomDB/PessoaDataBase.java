package com.example.db_room.roomDB;

import androidx.room.Database;

@Database(
        entities = [Pessoa::class],
        version = 1
)

abstract class PessoaData